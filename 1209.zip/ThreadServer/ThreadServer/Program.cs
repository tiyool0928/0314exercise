﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ThreadServer
{
    class Program
    {
        public static Hashtable clientsList = new Hashtable();
        static void Main(string[] args)
        {
            TcpListener serverSocket = new TcpListener(3000);
            TcpClient clientSocket = default(TcpClient);
            int counter = 0;

            serverSocket.Start();
            Console.WriteLine("Server Started");

            while (true)
            {
                counter += 1;
                clientSocket = serverSocket.AcceptTcpClient();

                NetworkStream netWorkStream = clientSocket.GetStream();
                int bufferSize = (int)clientSocket.ReceiveBufferSize;
                byte[] bytesFrom = new byte[bufferSize];
                netWorkStream.Read(bytesFrom, 0, bufferSize - 1);
                string dataFromC = Encoding.ASCII.GetString(bytesFrom);
                dataFromC = dataFromC.Substring(0, dataFromC.IndexOf("$"));

                clientsList.Add(dataFromC, clientSocket);

                Broadcast("Join: " + dataFromC, dataFromC, false);

                Console.WriteLine("Joined : "+ dataFromC);
                new HandleClient(clientSocket,dataFromC,clientsList);
            }
        }

        public static void Broadcast(string msg, string uName, bool flag)
        {
            foreach(DictionaryEntry Item in clientsList)
            {
                TcpClient broadcastSocket;
                broadcastSocket = (TcpClient)Item.Value;
                NetworkStream broadcastStream = broadcastSocket.GetStream();
                Byte[] broadcastBytes = null;

                if(flag == true)
                {
                    broadcastBytes = Encoding.ASCII.GetBytes(uName + ": " + msg);
                }
                else
                {
                    broadcastBytes = Encoding.ASCII.GetBytes(msg);
                }
                broadcastStream.Write(broadcastBytes, 0, broadcastBytes.Length);
                broadcastStream.Flush();
            }
        }
    }

    public class HandleClient
    {
        TcpClient clientSocket;
        string clNo;
        Hashtable clientsList;

        public HandleClient(TcpClient _clientSocket,string _clNo, Hashtable _clientsList)
        {
            clientSocket = _clientSocket;
            clNo = _clNo;
            clientsList = _clientsList;
            new Thread(DoChat).Start();
        }
        private void DoChat()
        {
            int requestCount = 0;
            string rCount = null;
            int bufferSize = (int)clientSocket.ReceiveBufferSize;
            byte[] bytesFrom = new byte[bufferSize];


            while (true)
            {
                try
                {
                    requestCount = requestCount + 1;
                    NetworkStream netWorkStream = clientSocket.GetStream();
                    netWorkStream.Read(bytesFrom, 0, bufferSize - 1);
                    string dataFromC = Encoding.ASCII.GetString(bytesFrom);
                    dataFromC = dataFromC.Substring(0, dataFromC.IndexOf("$"));
                    Console.WriteLine("Received Data:  "+ dataFromC);
                    rCount = Convert.ToString(requestCount);

                    Program.Broadcast(dataFromC, clNo, true);
                }
                catch
                {

                }
            }
  
        }
    }
}
